clc;
clear all;

%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Getting DATA from source file %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

dataa_audio=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\AB_sesli.xlsx"); % loading data
dataa_video=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\AB_video.xlsx"); % loading data
dataa_web=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\AB_web.xlsx"); % loading data


dataa_men=readtable("D:\Users\umran.kaya\Desktop\Mimarlik\ages_men.xlsx"); % loading data
dataa_women=readtable("D:\Users\umran.kaya\Desktop\Mimarlik\ages_women.xlsx"); % loading data


     %&& Filling missing values (using moving average method with length 5) and converting from table to array (matrix) &&%
EEG_audio=fill_missing_data(dataa_audio,5);
EEG_video=fill_missing_data(dataa_video,5);
EEG_web=fill_missing_data(dataa_web,5);

     %&& Calculating Arousal and Valence values and Resulting with converting them with normalization method &&%
                                        %%% for AUDIO EEG DATA %%%%
[arousal_audio,valence_audio]=arousal_valence_calc(EEG_audio); % a function that calculating the arousal and valence values
[arousal_audio_n,valence_audio_n]=norm_arousal_valence(arousal_audio,valence_audio); % a function that normalize the Arousal and Valence between [-1,1] interval
                                        %%% for VIDEO EEG DATA %%%%
[arousal_video,valence_video]=arousal_valence_calc(EEG_video); % a function that calculating the arousal and valence values
[arousal_video_n,valence_video_n]=norm_arousal_valence(arousal_video,valence_video); % a function that normalize the Arousal and Valence between [-1,1] interval
                                         %%% for WEB EEG DATA %%%%
[arousal_web,valence_web]=arousal_valence_calc(EEG_web); % a function that calculating the arousal and valence values
[arousal_web_n,valence_web_n]=norm_arousal_valence(arousal_web,valence_web); % a function that normalize the Arousal and Valence between [-1,1] interval

          %&& Calculating AW Index and Resulting with converting them with normalization method &&%
 %%% for AUDIO EEG DATA %%%%
 [AW_audio]=AW_calc(EEG_audio);
 [AW_audio_n]=norm_AW(AW_audio);
 %%% for VIDEO EEG DATA %%%%
 [AW_video]=AW_calc(EEG_video);
 [AW_video_n]=norm_AW(AW_video);
 %%% for WEB EEG DATA %%%%
 [AW_web]=AW_calc(EEG_web);
 [AW_web_n]=norm_AW(AW_web);
 
  
           %&& Calculating TETHA (Q) angle that shows the emotion in Russel's circle &&%
 %%% for AUDIO EEG DATA %%%%
 [all_angles_audio]=all_angles_calc(arousal_audio_n,valence_audio_n);
 %%% for VIDEO EEG DATA %%%%
 [all_angles_video]=all_angles_calc(arousal_video_n,valence_video_n);
 %%% for WEB EEG DATA %%%%
 [all_angles_web]=all_angles_calc(arousal_web_n,valence_web_n);
 
 
 %& Until this point, we got the data and make the preprocess (filling missing data,calc arousal/valence, AW,)
 %& Now, we will create the fuzzy sets. Before creating the protoforms, we should create the labels fuzzy sets to get membership degrees while
 %calculating the truth values.
 
 %%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Creating FUZZY SETS for ALL LABELS %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                                          
%& We have 2 type fuzzy sets. First one is about 3 type emotions (all emotion, basic emotions and AW index). 
%& Second type fuzzy sets is about Quantifiers. These quantifiers are {few, half, at_least_half, most, all}.
%& And more there is a label used for comparing is "more". 


%%%%%%%%%%%%------------------- Creating Granular Trend Detection -----------------%%%%%%%%%%%%%%%%%
 interval=3;
 number_of_member=3;
                             %%%%%%%--- for Russel Circle ---%%%%%%%%
 [ebs,group_points_audio,group_density_audio]=granular_trend_detection(all_angles_audio,interval,number_of_member);
 [ebs,group_points_video,group_density_video]=granular_trend_detection(all_angles_video,interval,number_of_member);
 [ebs,group_points_web,group_density_web]=granular_trend_detection(all_angles_web,interval,number_of_member);
 
                             %%%%%%%--- for AW Index ---%%%%%%%%
 [ebs,AW_group_points_audio,AW_group_density_audio]=granular_trend_detection(AW_audio_n',interval,number_of_member);
 [ebs,AW_group_points_video,AW_group_density_video]=granular_trend_detection(AW_video_n',interval,number_of_member);
 [ebs,AW_group_points_web,AW_group_density_web]=granular_trend_detection(AW_web_n',interval,number_of_member);

                     %&---------------- EMOTIONS FUZZY SETS---------------- %&
%& 1) ALL EMOTIONS LABELS:

labels_all_emotion={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'}; % labels used in emotion detection. This data used in label_fuzzy_set

% These "all_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*16*17. 
% It means that for all 17 people, 300 time points' value is converted to 16 emotions' membership degree.
 
[all_emotions_mmbrship_dgre_audio]=mem_degree_for_all_emotion(group_points_audio,labels_all_emotion);
[all_emotions_mmbrship_dgre_video]=mem_degree_for_all_emotion(group_points_video,labels_all_emotion);
[all_emotions_mmbrship_dgre_web]=mem_degree_for_all_emotion(group_points_web,labels_all_emotion);
 
 
 %& 2) BASIC EMOTIONS LABELS:

labels_basic_emotion={'thrilling','hard-pressed','pessimist','mitigated'}; % labels used in emotion detection. This data used in basic_labels_fuzzy_set

% These "basic_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*4*17. 
% It means that for all 17 people, 300 time points' value is converted to 4 emotions' membership degree.

[basic_emotions_mmbrship_dgre_audio]=mem_degree_for_basic_emotion(group_points_audio,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_video]=mem_degree_for_basic_emotion(group_points_video,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_web]=mem_degree_for_basic_emotion(group_points_web,labels_basic_emotion);

%& 3) AW INDEX LABELS:

labels_AW_emotion={'negative','neutral','positive'}; % labels used in emotion detection. This data used in AW_labels_fuzzy_set

% These "AW_index_mmbrship_dgre_audio/video/web" matrix size is 300*3*17. 
% It means that for all 17 people, 300 time points' value is converted to 3 emotions' membership degree.

[AW_membership_degree_audio]=mem_degree_for_AW_index(AW_group_points_audio,labels_AW_emotion);
[AW_membership_degree_video]=mem_degree_for_AW_index(AW_group_points_video,labels_AW_emotion);
[AW_membership_degree_web]=mem_degree_for_AW_index(AW_group_points_web,labels_AW_emotion);

%& 4) AGE LABELS:
gender={'women','men'};
Prequantifier={'young','adult','old'};
[pre_raw,pre_col]=size(Prequantifier);

% Totaly, there are 17 volunteer. 5 of these are women and 12 of these are men.
% We create 3 labeled fuzzy sets {'young','adult','old'} for each gender.

[mmbrship_dgre_men]=fuzzy_c_means(dataa_men,pre_col);
[mmbrship_dgre_women]=fuzzy_c_means(dataa_women,pre_col);


%& 5) DENSITY LABELS:
density={'small','normal','big', 'very big'};
[den_raw,den_col]=size(density);

                      %----THETA density membership function-----%
% We have 3 labels; {'big','normal','small'} and the data from THETA has been grouped by granular trend algorithm 
% and their group density membership according to labels calculated below;
[points_raw,people_col]=size(arousal_audio);

[theta_density_memberships_audio]=fuzzy_clustering(group_density_audio,den_col,people_col);
[theta_density_memberships_video]=fuzzy_clustering(group_density_video,den_col,people_col);
[theta_density_memberships_web]=fuzzy_clustering(group_density_web,den_col,people_col);

                      %----AW index density membership function-----%
%the data from AW index has been grouped by granular trend algorithm 
% and their group density membership according to labels calculated below;

[AW_density_memberships_audio]=fuzzy_clustering(AW_group_density_audio,den_col,people_col);
[AW_density_memberships_video]=fuzzy_clustering(AW_group_density_video,den_col,people_col);
[AW_density_memberships_web]=fuzzy_clustering(AW_group_density_web,den_col,people_col);


%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------%%% LINGUISTIC SUMMARIES %%%%-----------------------------------%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

Y_ad={'audio','video','web'};
Quantifier={'few','most','half','at least half','all'};

% treshold=input('Please, write the TRESHOLD:  '); % indicates the minimum truth degree to be referenced
% seg_number=input('Please, write the SEGMENTATION NUMBER:  ');  % shows how many segments it will examine the ad.
treshold=0.00001; % indicates the minimum truth degree to be referenced
seg_number=4;  % shows how many segments it will examine the ad.

% There are 2 type descriptions. First type is general descriptions has 3 protoforms. 
% Second type of description is comparing ads, ads' parts and emotions. 

%*******-----------------------A)GENERAL DESCRIPTIONS-----------------------*******%
%  1) 1. protoform for each 3 advertising type.
%------"Q time of Y2 ad, S emotion are observed simultaneously as a group.[TD]"--------%
% 1.1) Sentences created by all_emotions
[GTD_P1_audio_all_emotion,GTD_P1_video_all_emotion,GTD_P1_web_all_emotion]=granular_TD_protoform_1(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold);
% 1.2) Sentences created by basic_emotions
[GTD_P1_audio_basic_emotion,GTD_P1_video_basic_emotion,GTD_P1_web_basic_emotion]=granular_TD_protoform_1(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,Y_ad,treshold);
% 1.3) Sentences created by AW index
[GTD_P1_audio_AW,GTD_P1_video_AW,GTD_P1_web_AW]=granular_TD_protoform_1(Quantifier,labels_AW_emotion,AW_membership_degree_audio,AW_membership_degree_video,AW_membership_degree_web,Y_ad,treshold);

%  2) 2. protoform for each 3 advertising type
%------"Q time of the Y3 quarter of Y2 ad, S emotion are observed simultaneously as a group.[TD]"-----%
% 2.1) Sentences created by all_emotions
[allsize,allcol]=size(EEG_audio);
[GTD_P2_audio_all_emotion,GTD_P2_video_all_emotion,GTD_P2_web_all_emotion]=granular_TD_protoform_2(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold,seg_number,allsize);
% 2.2) Sentences created by basic_emotions
[GTD_P2_audio_basic_emotion,GTD_P2_video_basic_emotion,GTD_P2_web_basic_emotion]=granular_TD_protoform_2(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,Y_ad,treshold,seg_number,allsize);
% 2.3) Sentences created by basic_emotions
[GTD_P2_audio_AW,GTD_P2_video_AW,GTD_P2_web_AW]=granular_TD_protoform_2(Quantifier,labels_AW_emotion,AW_membership_degree_audio,AW_membership_degree_video,AW_membership_degree_web,Y_ad,treshold,seg_number,allsize);


%  3) 3. protoform for each 3 advertising type
%------"Q time of Y2 ad, S was observed by a Y4 crowd.[TD]"--------%
% 3.1) Sentences created by all_emotions
[GTD_P3_audio_all_emotion,GTD_P3_video_all_emotion,GTD_P3_web_all_emotion]=granular_TD_protoform_3(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,theta_density_memberships_audio,theta_density_memberships_video,theta_density_memberships_web,Y_ad,density,treshold);
% 3.2) Sentences created by basic_emotions
[GTD_P3_audio_basic_emotion,GTD_P3_video_basic_emotion,GTD_P3_web_basic_emotion]=granular_TD_protoform_3(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,theta_density_memberships_audio,theta_density_memberships_video,theta_density_memberships_web,Y_ad,density,treshold);
% 3.3) Sentences created by AW index
[GTD_P3_audio_AW,GTD_P3_video_AW,GTD_P3_web_AW]=granular_TD_protoform_3(Quantifier,labels_AW_emotion,AW_membership_degree_audio,AW_membership_degree_video,AW_membership_degree_web,AW_density_memberships_audio,AW_density_memberships_video,AW_density_memberships_web,Y_ad,density,treshold);



%  4) 4. protoform for each 3 advertising type
%------"Q time of Y3 quarter in Y2 ad, S was observed by a Y4 crowd.[TD]"--------%
% 4.1) Sentences created by all_emotions
[GTD_P4_audio_all_emotion,GTD_P4_video_all_emotion,GTD_P4_web_all_emotion]=granular_TD_protoform_4(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,theta_density_memberships_audio,theta_density_memberships_video,theta_density_memberships_web,Y_ad,density,treshold,seg_number,allsize);
% 4.2) Sentences created by basic_emotions
[GTD_P4_audio_basic_emotion,GTD_P4_video_basic_emotion,GTD_P4_web_basic_emotion]=granular_TD_protoform_4(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,theta_density_memberships_audio,theta_density_memberships_video,theta_density_memberships_web,Y_ad,density,treshold,seg_number,allsize);
% 4.3) Sentences created by AW index
[GTD_P4_audio_AW,GTD_P4_video_AW,GTD_P4_web_AW]=granular_TD_protoform_4(Quantifier,labels_AW_emotion,AW_membership_degree_audio,AW_membership_degree_video,AW_membership_degree_web,AW_density_memberships_audio,AW_density_memberships_video,AW_density_memberships_web,Y_ad,density,treshold,seg_number,allsize);



% The positive effect seen as a group in the 1st ad is greater than in the 2nd ad.
[GTD_P5_Comparing_Ads]=granular_TD_protoform_5(AW_membership_degree_audio,AW_membership_degree_video,AW_membership_degree_web,Y_ad,treshold);





