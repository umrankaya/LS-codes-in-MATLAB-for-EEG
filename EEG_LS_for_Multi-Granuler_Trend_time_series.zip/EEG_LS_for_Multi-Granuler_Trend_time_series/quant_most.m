function [ y ] = quant_most( x )
%UNT�TLED2 Summary of this function goes here
%   Detailed explanation goes here
lmt=0.99;
if x<=0.5
    y=0;
elseif x<=lmt
    y=(x-0.5)/(lmt-0.5);
else
    y=1;
end
end