function [all_angles]=all_angles_calc(arousal,valence)
% Each EEG signal's membership degree to emotional labels will be
% calculated as using label_fuzzy_labels function
all_angles=[]; % All angles are kept in this matris

[num_of_points,num_of_people]=size(arousal);

for p=1:num_of_people
    angles=[];
    for t=1:num_of_points
        [fs]=angle_calc(arousal(t,p),valence(t,p)); % calculating with iteration
        angles=[angles,fs]; % Each angle added to matris
    end
        all_angles=[all_angles;angles]; % Each angle added to matris   
end
end