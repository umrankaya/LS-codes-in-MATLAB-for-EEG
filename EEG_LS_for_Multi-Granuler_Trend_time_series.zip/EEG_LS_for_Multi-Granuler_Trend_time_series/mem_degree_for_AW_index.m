function [membership_degree]=mem_degree_for_AW_index(aw,labels)
% Each EEG signal's membership degree to emotional labels will be calculated as using AW_labels_fuzzy_set function

membership_degree=[]; % an empty matris to fill with membersip degree for each EEG signal (time_points_300*emotions_3*people_17)(300*3*17)

[num_of_points,num_of_people]=size(aw); %300*17

for p=1:num_of_people
    for t=1:num_of_points

        [label_values]=AW_labels_fuzzy_set(aw(t,p),labels); % calculating with iteration
        membership_degree(t,:,p)=label_values; % collecting in this matris

    end
end
end