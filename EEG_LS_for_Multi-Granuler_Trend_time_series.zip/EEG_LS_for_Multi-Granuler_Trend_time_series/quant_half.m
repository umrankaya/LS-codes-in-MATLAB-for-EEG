function [ y ] = quant_half( x )
%UNT�TLED3 Summary of this function goes here
%   Detailed explanation goes here
if x<=0.25
    y=0;
elseif x<=0.5
    y=(x-0.25)/0.25;
elseif x<=0.75
    y=(0.75-x)/0.25;
else
    y=0;
end
end
