function [fs]=angle_calc(ar,val)

% In this functin, we calculate the membership degree of any arousal/valence values according to labels
%First we defined whole labels and then added local labels for each quadrant.

fi=0; % fi shows the angle 

% For arousal and valuence values, quadrant is detected and angle is calculated
if ar>0 && val>0
    fi=atan(ar/val);
elseif ar>0 && val<0
    fi=pi-abs(atan(ar/val));
elseif ar<0 && val<0
    fi=pi+atan(ar/val);        
else
    fi=2*pi-abs(atan(ar/val));   
end

fs=fi;














end