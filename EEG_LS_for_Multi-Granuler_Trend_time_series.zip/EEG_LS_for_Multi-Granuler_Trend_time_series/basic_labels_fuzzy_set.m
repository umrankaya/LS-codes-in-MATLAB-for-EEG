function [fs,label_values]=basic_labels_fuzzy_set(fi,labels)

% In this functin, we calculate the membership degree of any arousal/valence values according to labels
%First we defined whole labels and then added local labels for each quadrant.

% labels_all_emotion={'thrilling','hard-pressed','pessimist','mitigated'}

% we wanna create a matris to write memebership degree for each labels
sz=size(labels); 
label_values=zeros(1,sz(1,2)); % for each angle, membership degree will be written to this matris

fs=fi;

if fi<=(pi/6)
   label_values(1,1)=((3*fi)/pi+0.5);
   label_values(1,4)=(0.5-(3*fi)/pi); 
   
elseif fi>(pi/6) && fi<=(pi/3)
   label_values(1,1)=1;
   
elseif fi>(pi/3) && fi<=(2*pi/3)
   label_values(1,1)=(2-(3*fi)/pi);
   label_values(1,2)=((3*fi)/pi-1); 

elseif fi>(2*pi/3) && fi<=(5*pi/6)
   label_values(1,2)=1;
   
elseif fi>(5*pi/6) && fi<=(7*pi/6)
   label_values(1,2)=(3.5-(3*fi)/pi);
   label_values(1,3)=((3*fi)/pi-2.5);  

elseif fi>(7*pi/6) && fi<=(4*pi/3)
   label_values(1,3)=1;

elseif fi>(4*pi/3) && fi<=(5*pi/3)
   label_values(1,3)=(5-(3*fi)/pi);
   label_values(1,4)=((3*fi)/pi-4);
   
elseif fi>(5*pi/3) && fi<=(11*pi/6)
   label_values(1,4)=1;

else
   label_values(1,4)=(6.5-(3*fi)/(pi));
   label_values(1,1)=((3*fi)/pi-5.5); 
   
end