function [label_values]=AW_labels_fuzzy_set(aw,labels)

% In this functin, we calculate the membership degree of any AW values according to labels
%First we defined whole labels.

% labels_AW_emotion={'negative','neutral','positive'};

% we wanna create a matris to write memebership degree for each labels
sz=size(labels); 
label_values=zeros(1,sz(1,2)); % for each angle, membership degree will be written to this matris

if isnan(aw)
   label_values(1,1)=NaN;
   label_values(1,2)=NaN;
   label_values(1,3)=NaN;

elseif aw <=(-0.6)
   label_values(1,1)=1;
   
elseif aw <=(-0.2)
   label_values(1,1)=(-0.5-2.5*aw);
   label_values(1,2)=(2.5*aw+1.5);
   
elseif aw <=(0.2)
   label_values(1,2)=1; 

elseif aw <=(0.6)
   label_values(1,2)=(1.5-2.5*aw);
   label_values(1,3)=(2.5*aw-0.5);
 
else
   label_values(1,3)=1; 
   
end