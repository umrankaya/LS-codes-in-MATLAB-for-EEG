function [TD]=truth_degree_4(q,s,pr,all_emotions_mmbrship_dgre,theta_density_memberships,seg_number,segment_part,allsize)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,

[points_size_a,label_size,all_time_a]=size(theta_density_memberships);
variable=allsize/seg_number; % calculating the segment amount in data (75)
start_p=((segment_part-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
finish_p=segment_part*variable; % calculating finish point of segment (for example: 3. segment finish point is 225

numerator=0;
denominator=0;

for hn=start_p:finish_p 
    if hn<=all_time_a
        for pn=1:points_size_a
            td_a=theta_density_memberships(pn,pr,hn); 
            td_b=all_emotions_mmbrship_dgre(pn,s,hn);
            if ~isnan(td_a)&& td_b>0
                numerator=numerator+ min(td_a,td_b); % calculated numerator in the formula of type-2
                denominator=denominator+td_b; % calculated denominator in the formula of type-2
            end        
        end
    end
end

if denominator~=0
       tdd=numerator/denominator;
%        All quantifier functions are defined before and used when they are choosen
        if q==1
            [ TD ] = quant_few(tdd); 
        elseif q==2
            [ TD ] = quant_most(tdd);
        elseif q==3
            [ TD ] = quant_half(tdd);
        elseif q==4
            [ TD ] = quant_at_least_half(tdd);
        else
            [ TD ] = quant_all(tdd);
        end       
else
    TD=0;
end

end