function [membership_degree]=mem_degree_for_all_emotion(group_points,labels)
% Each EEG signal's membership degree to emotional labels will be
% calculated as using label_fuzzy_labels function
membership_degree=[]; % an empty matris to fill with membersip degree for each EEG signal (time_points_298*emotions_16*deep_15)(300*16*15)
all_angles=[]; % All angles are kept in this matris

[num_of_deep,num_of_points]=size(group_points);

for p=1:num_of_points
    for t=1:num_of_deep

        [fs,label_values]=all_emotions_label_fuzzy_set(group_points(t,p),labels); % calculating with iteration
        all_angles=[all_angles,fs]; % Each angle added to matris
        membership_degree(t,:,p)=label_values; % collecting in this matris

    end
end
end