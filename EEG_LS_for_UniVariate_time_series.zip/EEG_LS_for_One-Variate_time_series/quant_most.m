function [ y ] = quant_most( x )
%UNT�TLED2 Summary of this function goes here
%   Detailed explanation goes here
if x<=0.5
    y=0;
elseif x<=0.75
    y=(x-0.5)/0.25;
else
    y=1;
end
end