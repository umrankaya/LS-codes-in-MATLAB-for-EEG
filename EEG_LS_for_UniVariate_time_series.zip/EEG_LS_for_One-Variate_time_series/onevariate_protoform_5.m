function [OV_P5_audio_Comparative,OV_P5_video_Comparative,OV_P5_web_Comparative]=onevariate_protoform_5(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function


[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
OV_P5_audio_Comparative=[];
OV_P5_video_Comparative=[];
OV_P5_web_Comparative=[];

for ad=1:ad_number % looking for ad number
    for n=1:people   % looking for number of volunteer
        for seg1=1:seg_number % looking for each segment of data
            for seg2=1:seg_number % looking for each segment of data
                if seg1~=seg2
                    if ad==1 % for Audio ad
                        [TD]=truth_degree_5(AW_index_mmbrship_dgre_audio,n,seg_number,seg1,seg2);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter for volunteer ',n,num2str(TD)];
                            OV_P5_audio_Comparative=[OV_P5_audio_Comparative;sentence];
                        end
                    elseif ad==2 % for Video ad
                        [TD]=truth_degree_5(AW_index_mmbrship_dgre_video,n,seg_number,seg1,seg2);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter for volunteer ',n,num2str(TD)];
                            OV_P5_video_Comparative=[OV_P5_video_Comparative;sentence];
                        end
                    else % for Web ad
                        [TD]=truth_degree_5(AW_index_mmbrship_dgre_web,n,seg_number,seg1,seg2);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter for volunteer ',n,num2str(TD)];
                            OV_P5_web_Comparative=[OV_P5_web_Comparative;sentence];
                        end
                    end
                end
            end
        end
    end
end
end