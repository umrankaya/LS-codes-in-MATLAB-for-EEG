function [TD]=truth_degree_8(s1,s2,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,people_number,ad1,ad2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 's' represents the used Summerizer (emotion label).
% 'all_emotions_mmbrship_dgre_audio' represents calculated membership degree matrix,
% 'people_number'represents which volunteers' data used.
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre_audio);


%%% Calculatig the Ad1's TD
if ad1==1
    td1=(sum(all_emotions_mmbrship_dgre_audio(:,s1,people_number)))/(points_size); 
elseif ad1==2
    td1=(sum(all_emotions_mmbrship_dgre_video(:,s1,people_number)))/(points_size);  
else
    td1=(sum(all_emotions_mmbrship_dgre_web(:,s1,people_number)))/(points_size);      
end


%%% Calculatig the Ad2's TD
if ad2==1
    td2=(sum(all_emotions_mmbrship_dgre_audio(:,s2,people_number)))/(points_size); 
elseif ad2==2
    td2=(sum(all_emotions_mmbrship_dgre_video(:,s2,people_number)))/(points_size);   
else
    td2=(sum(all_emotions_mmbrship_dgre_web(:,s2,people_number)))/(points_size);      
end

td=min(td1,td2);

% 'most' quantifier functions are defined before.

    [ TD ] = quant_most(td);
end