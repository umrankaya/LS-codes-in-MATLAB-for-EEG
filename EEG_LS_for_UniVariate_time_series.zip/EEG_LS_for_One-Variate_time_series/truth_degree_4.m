function [TD]=truth_degree_4(q,s,all_emotions_mmbrship_dgre,people_number,seg_number,segment_part)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,
% 'people_number'represents which volunteers' data used.
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre);
variable=points_size/seg_number; % calculating the segment amount in data (75)
start_p=((segment_part-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
finish_p=segment_part*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)

td=(sum(all_emotions_mmbrship_dgre(start_p:finish_p,s,people_number)))/(variable);

% All quantifier functions are defined before and used when they are choosen

if q==1
    [ TD ] = quant_few(td); 
    
elseif q==2
    [ TD ] = quant_most(td);

elseif q==3
    [ TD ] = quant_half(td);
    
elseif q==4
    [ TD ] = quant_at_least_half(td);

else
    [ TD ] = quant_all(td);
end

end