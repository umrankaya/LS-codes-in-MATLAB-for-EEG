function [OV_P6_Comparing_Ads]=onevariate_protoform_6(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
OV_P6_Comparing_Ads=[];

for ad1=1:ad_number % looking for ad1 number
    for ad2=1:ad_number % looking for ad2 number
        if ad1~=ad2  % looking for not to be the same ad.
           for n=1:people   % looking for number of volunteer
               [TD]=truth_degree_6(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,n,ad1,ad2);
               
               if TD>=treshold
                   % Creating summarization and Truth Degree of summary
                  sentence=['For volunteer_',n,', ',Y_ad(1,ad1),'ad','has a MORE POSITIVE impact then the ',Y_ad(1,ad2),'ad',num2str(TD)];
                  OV_P6_Comparing_Ads=[OV_P6_Comparing_Ads;sentence];
               end
               
            end
        end
    end
end
end




