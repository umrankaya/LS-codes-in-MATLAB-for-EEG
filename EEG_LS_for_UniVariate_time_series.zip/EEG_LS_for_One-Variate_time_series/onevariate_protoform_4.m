function [OV_P4_audio_AW_index,OV_P4_video_AW_index,OV_P4_web_AW_index]=onevariate_protoform_4(Quantifier,labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fq,quant]=size(Quantifier);
[fl,summarizer]=size(labels_AW_emotion);
[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
OV_P4_audio_AW_index=[];
OV_P4_video_AW_index=[];
OV_P4_web_AW_index=[];

for ad=1:ad_number % looking for ad number
    for n=1:people   % looking for number of volunteer
        for q=1:quant  % looking for each used quantifier
            for s=1:summarizer % looking for each used emotion
                for seg=1:seg_number % looking for each segment of data
                    if ad==1 % for Audio ad
                        [TD]=truth_degree_4(q,s,AW_index_mmbrship_dgre_audio,n,seg_number,seg);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Quantifier(1,q),'time of ','quarter_',seg,'of  ',Y_ad(1,ad),'ad,  volunteer',n,'has',labels_AW_emotion(1,s),'tends for ad',num2str(TD)];
                            OV_P4_audio_AW_index=[OV_P4_audio_AW_index;sentence];
                        end
                    elseif ad==2 % for Video ad
                        [TD]=truth_degree_4(q,s,AW_index_mmbrship_dgre_video,n,seg_number,seg);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Quantifier(1,q),'time of ','quarter_',seg,'of  ',Y_ad(1,ad),'ad,  volunteer',n,'has',labels_AW_emotion(1,s),'tends for ad',num2str(TD)];
                            OV_P4_video_AW_index=[OV_P4_video_AW_index;sentence];
                        end
                    else % for Web ad
                        [TD]=truth_degree_4(q,s,AW_index_mmbrship_dgre_web,n,seg_number,seg);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Quantifier(1,q),'time of ','quarter_',seg,'of  ',Y_ad(1,ad),'ad,  volunteer',n,'has',labels_AW_emotion(1,s),'tends for ad',num2str(TD)];
                            OV_P4_web_AW_index=[OV_P4_web_AW_index;sentence];
                        end
                    end
                end
            end
        end
    end
end
end