function [TD]=truth_degree_7(q1,q2,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,people_number,ad1,ad2,seg_number,segment_part1,segment_part2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 's' represents the used Summerizer (emotion label),  BUT IN THIS DESC. WE ALL USE 'POSITIVE' LABEL. SO FIXED S=3.
% 'AW_index_mmbrship_dgre_audio' represents calculated membership degree matrix,
% 'people_number'represents which volunteers' data used.
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);
variable=points_size/seg_number; % calculating the segment amount in data (75)

%%% Calculatig the Ad1's TD
if ad1==1
        %%% Calculatig the segment_part1's TD
    start_p_1=((segment_part1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_1=segment_part1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td1=(sum(AW_index_mmbrship_dgre_audio(start_p_1:finish_p_1,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q1==1
        [ TD_1 ] = quant_few(td1); 

    elseif q1==2
        [ TD_1 ] = quant_most(td1);

    elseif q1==3
        [ TD_1 ] = quant_half(td1);

    elseif q1==4
        [ TD_1 ] = quant_at_least_half(td1);

    else
        [ TD_1 ] = quant_all(td1);
    end

elseif ad1==2
        %%% Calculatig the segment_part1's TD
    start_p_1=((segment_part1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_1=segment_part1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td1=(sum(AW_index_mmbrship_dgre_video(start_p_1:finish_p_1,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q1==1
        [ TD_1 ] = quant_few(td1); 

    elseif q1==2
        [ TD_1 ] = quant_most(td1);

    elseif q1==3
        [ TD_1 ] = quant_half(td1);

    elseif q1==4
        [ TD_1 ] = quant_at_least_half(td1);

    else
        [ TD_1 ] = quant_all(td1);
    end

else
        %%% Calculatig the segment_part1's TD
    start_p_1=((segment_part1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_1=segment_part1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td1=(sum(AW_index_mmbrship_dgre_web(start_p_1:finish_p_1,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q1==1
        [ TD_1 ] = quant_few(td1); 

    elseif q1==2
        [ TD_1 ] = quant_most(td1);

    elseif q1==3
        [ TD_1 ] = quant_half(td1);

    elseif q1==4
        [ TD_1 ] = quant_at_least_half(td1);

    else
        [ TD_1 ] = quant_all(td1);
    end

end


%%% Calculatig the Ad2's TD
if ad2==1
        %%% Calculatig the segment_part1's TD
    start_p_2=((segment_part2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_2=segment_part2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td2=(sum(AW_index_mmbrship_dgre_audio(start_p_2:finish_p_2,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q2==1
        [ TD_2 ] = quant_few(td2); 

    elseif q2==2
        [ TD_2 ] = quant_most(td2);

    elseif q2==3
        [ TD_2 ] = quant_half(td2);

    elseif q2==4
        [ TD_2 ] = quant_at_least_half(td2);

    else
        [ TD_2 ] = quant_all(td2);
    end

elseif ad2==2
        %%% Calculatig the segment_part1's TD
    start_p_2=((segment_part2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_2=segment_part2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td2=(sum(AW_index_mmbrship_dgre_video(start_p_2:finish_p_2,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q2==1
        [ TD_2 ] = quant_few(td2); 

    elseif q2==2
        [ TD_2 ] = quant_most(td2);

    elseif q2==3
        [ TD_2 ] = quant_half(td2);

    elseif q2==4
        [ TD_2 ] = quant_at_least_half(td2);

    else
        [ TD_2 ] = quant_all(td2);
    end

else
        %%% Calculatig the segment_part1's TD
    start_p_2=((segment_part2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
    finish_p_2=segment_part2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
    td2=(sum(AW_index_mmbrship_dgre_web(start_p_2:finish_p_2,3,people_number)))/(variable); % 3 is used to calculate 'positive' label
    
    if q2==1
        [ TD_2 ] = quant_few(td2); 

    elseif q2==2
        [ TD_2 ] = quant_most(td2);

    elseif q2==3
        [ TD_2 ] = quant_half(td2);

    elseif q2==4
        [ TD_2 ] = quant_at_least_half(td2);

    else
        [ TD_2 ] = quant_all(td2);
    end

end

TD=min(TD_1,TD_2);

end