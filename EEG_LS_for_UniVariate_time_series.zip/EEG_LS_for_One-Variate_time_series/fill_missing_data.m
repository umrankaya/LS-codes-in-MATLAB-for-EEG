function f=fill_missing_data(data,length)

% if the data is table, then it will be converted to array
% The missing values should be showen as "NaN". otherwise it result "0".

q=istable(data);
if q==1
    data=table2array(data);
end

% filling missing values
% "length" is moving average step size. Generally got as 5.
ff = fillmissing(data,'movmedian',length);

%if there is still more NaN value(s), then fill until all missing value(s) will be done.
sz=size(ff);
rw=sz(1,1);
clmn=sz(1,2);

for i=1:rw
    for j=1:clmn
        if isnan(ff(i,j))
           ff = fillmissing(ff,'movmedian',length); 
        end      
    end
end
f=ff;
end