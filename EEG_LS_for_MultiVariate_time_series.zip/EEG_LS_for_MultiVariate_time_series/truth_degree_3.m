function [TD]=truth_degree_3(q,s,all_emotions_mmbrship_dgre)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre);
td=(sum(sum(all_emotions_mmbrship_dgre(:,s,:))))/(points_size*people);

% All quantifier functions are defined before and used when they are choosen

if q==1
    [ TD ] = quant_few(td); 
    
elseif q==2
    [ TD ] = quant_most(td);

elseif q==3
    [ TD ] = quant_half(td);
    
elseif q==4
    [ TD ] = quant_at_least_half(td);

else
    [ TD ] = quant_all(td);
end

end