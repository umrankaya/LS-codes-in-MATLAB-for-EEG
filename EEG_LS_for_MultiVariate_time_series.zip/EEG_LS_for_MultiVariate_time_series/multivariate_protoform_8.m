function [MV_P8_Comparing_Ads]=multivariate_protoform_8(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
MV_P8_Comparing_Ads=[];

for ad1=1:ad_number % looking for ad1 number
    for ad2=1:ad_number % looking for ad2 number
        if ad1~=ad2  % looking for not to be the same ad.
           [TD]=truth_degree_8(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,ad1,ad2);

           if TD>=treshold
               % Creating summarization and Truth Degree of summary
              sentence=['In general',Y_ad(1,ad1),'ad','has a MORE POSITIVE impact then the ',Y_ad(1,ad2),'ad',num2str(TD)];
              MV_P8_Comparing_Ads=[MV_P8_Comparing_Ads;sentence];
           end            
        end
    end
end
end




