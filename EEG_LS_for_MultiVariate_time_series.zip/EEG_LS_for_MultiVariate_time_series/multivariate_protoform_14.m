function [MV_P14_Comparing_Ads]=multivariate_protoform_14(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,gender,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

% [points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
[fe,gender_number]=size(gender);
MV_P14_Comparing_Ads=[];

for gend=1:gender_number
    if gend==1
        for ad=1:ad_number % looking for ad1 number
           [TD]=truth_degree_14(gend,ad,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women);
           if TD>=treshold
               % Creating summarization and Truth Degree of summary
              sentence=[gender(1,1), 'are more affected pozitively by' ,Y_ad(1,ad),'ad than',gender(1,2),num2str(TD)];
              MV_P14_Comparing_Ads=[MV_P14_Comparing_Ads;sentence];
           end            
        end

    else
        for ad=1:ad_number % looking for ad1 number
           [TD]=truth_degree_14(gend,ad,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women);
           if TD>=treshold
               % Creating summarization and Truth Degree of summary
              sentence=[gender(1,2), 'are more affected pozitively by' ,Y_ad(1,ad),'ad than',gender(1,1),num2str(TD)];
              MV_P14_Comparing_Ads=[MV_P14_Comparing_Ads;sentence];
           end            
        end 
        
    end
    
end

end




