function [MV_P6_audio_sentences,MV_P6_video_sentences,MV_P6_web_sentences]=multivariate_protoform_6(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fa,quant]=size(Quantifier);
[fb,summarizer]=size(labels_all_emotion);
[fc,ad_number]=size(Y_ad);
[fd,prequant]=size(Prequantifier);
[fe,gender_number]=size(gender);

MV_P6_audio_sentences=[];
MV_P6_video_sentences=[];
MV_P6_web_sentences=[];

for ad=1:ad_number % looking for ad number
    for q=1:quant  % looking for each used quantifier
        for s=1:summarizer % looking for each used emotion
            for seg=1:seg_number % looking for each segment
                for pr=1:prequant % looking for each used pre-quantifier
                    for gend=1:gender_number
                        if ad==1 % for Audio ad
                            [TD]=truth_degree_6(q,s,pr,gend,all_emotions_mmbrship_dgre_audio,mmbrship_dgre_men,mmbrship_dgre_women,seg_number,seg);
                            if TD>=treshold
                                % Creating summarization and Truth Degree of summary
                                sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are ',labels_all_emotion(1,s),' in the','quarter_',seg,'of the',Y_ad(1,ad),'ad',num2str(TD)];
                                MV_P6_audio_sentences=[MV_P6_audio_sentences;sentence];
                            end
                        elseif ad==2 % for Video ad
                            [TD]=truth_degree_6(q,s,pr,gend,all_emotions_mmbrship_dgre_video,mmbrship_dgre_men,mmbrship_dgre_women,seg_number,seg);
                            if TD>=treshold
                                % Creating summarization and Truth Degree of summary
                                sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are ',labels_all_emotion(1,s),' in the','quarter_',seg,'of the',Y_ad(1,ad),'ad',num2str(TD)];
                                MV_P6_video_sentences=[MV_P6_video_sentences;sentence];
                            end
                            
                        else % for Web ad
                            [TD]=truth_degree_6(q,s,pr,gend,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,seg_number,seg);
                            if TD>=treshold
                                % Creating summarization and Truth Degree of summary
                                sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are ',labels_all_emotion(1,s),' in the','quarter_',seg,'of the',Y_ad(1,ad),'ad',num2str(TD)];
                                MV_P6_web_sentences=[MV_P6_web_sentences;sentence];
                            end    
                        end
                    end
                end
            end
        end
    end
end
end