function [MV_P13_audio_sentences,MV_P13_video_sentences,MV_P13_web_sentences]=multivariate_protoform_13(all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fc,ad_number]=size(Y_ad);
[fd,prequant]=size(Prequantifier);
[fe,gender_number]=size(gender);

MV_P13_audio_sentences=[];
MV_P13_video_sentences=[];
MV_P13_web_sentences=[];

for ad=1:ad_number % looking for ad number
    for gend=1:gender_number
        for pr1=1:prequant % looking for each segment of data
            for pr2=1:prequant % looking for each segment of data
                if pr1~=pr2
                    if ad==1 % for Audio ad
                        [TD]=truth_degree_13(gend,pr1,pr2,all_emotions_mmbrship_dgre_audio,mmbrship_dgre_men,mmbrship_dgre_women);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Prequantifier(1,pr1),gender(1,gend),' are MORE affected pozitively by the ',Y_ad(1,ad),'ad  then the ',Prequantifier(1,pr2),gender(1,gend),num2str(TD)];
                            MV_P13_audio_sentences=[MV_P13_audio_sentences;sentence];
                        end
                    elseif ad==2 % for Video ad
                        [TD]=truth_degree_13(gend,pr1,pr2,all_emotions_mmbrship_dgre_video,mmbrship_dgre_men,mmbrship_dgre_women);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Prequantifier(1,pr1),gender(1,gend),' are MORE affected pozitively by the ',Y_ad(1,ad),'ad  then the ',Prequantifier(1,pr2),gender(1,gend),num2str(TD)];
                            MV_P13_video_sentences=[MV_P13_video_sentences;sentence];
                        end
                    else % for Web ad
                        [TD]=truth_degree_13(gend,pr1,pr2,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women);
                        if TD>=treshold
                            % Creating summarization and Truth Degree of summary
                            sentence=[Prequantifier(1,pr1),gender(1,gend),' are MORE affected pozitively by the ',Y_ad(1,ad),'ad  then the ',Prequantifier(1,pr2),gender(1,gend),num2str(TD)];
                            MV_P13_web_sentences=[MV_P13_web_sentences;sentence];
                        end
                    end
                end
            end
        end                   
    end
end
end