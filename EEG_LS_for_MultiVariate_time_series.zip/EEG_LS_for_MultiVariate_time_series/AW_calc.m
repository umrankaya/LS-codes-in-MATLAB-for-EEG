function [AW]=AW_calc(data)

[num_of_points,coloumn]=size(data); % Calculated the size of EEG signal points
iteration_size=coloumn/4; % should be 17

%This function is created to calculate the AW index from frontol alpha signals. 
%Aldayel, M., M. Ykhlef, and A. Al-Nafjan, Deep Learning for EEG-Based Preference Classification in Neuromarketing. Applied sciences, 2020: p. 1-23

AW=[];

for i=1:iteration_size
    
    %Extracting features
    a_AF7=data(:,(4*i-3));
    a_AF8=data(:,(4*i-2));
    
    AWW=((a_AF8)-(a_AF7))./((a_AF8)+(a_AF7)); %formula
    
    % Creating AW data
    AW(:,i)=AWW(:,:);
end