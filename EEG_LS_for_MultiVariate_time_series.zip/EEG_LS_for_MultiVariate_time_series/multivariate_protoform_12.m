function [MV_P12_Comparing_Ads]=multivariate_protoform_12(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,gender,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[fy,ad_number]=size(Y_ad);
[fe,gender_number]=size(gender);
MV_P12_Comparing_Ads=[];

for gend=1:gender_number
    for ad1=1:ad_number % looking for ad1 number
        for ad2=1:ad_number % looking for ad2 number
            if ad1~=ad2  % looking for not to be the same ad.
               [TD]=truth_degree_12(gend,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,ad1,ad2);

               if TD>=treshold
                   % Creating summarization and Truth Degree of summary
                  sentence=['In general',Y_ad(1,ad1),'ad','affects POSITIVELY',gender(1,gend), 'more than ',Y_ad(1,ad2),'ad',num2str(TD)];
                  MV_P12_Comparing_Ads=[MV_P12_Comparing_Ads;sentence];
               end            
            end
        end
    end
end

end




