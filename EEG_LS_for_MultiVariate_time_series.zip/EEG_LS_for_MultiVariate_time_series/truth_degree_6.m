function [TD]=truth_degree_6(q,s,pr,gend,all_emotions_mmbrship_dgre,mmbrship_dgre_men,mmbrship_dgre_women,seg_number,seg)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre);
variable=points_size/seg_number; % calculating the segment amount in data (75)
start_p=((seg-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
finish_p=seg*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)

[group1,women_number]=size(mmbrship_dgre_women); % there are 5 women 
[group2,men_number]=size(mmbrship_dgre_men); % there are 12 men 

if gend==1 % if gender is women
    numerator=0;
    denominator=0;
    
    for h=1:women_number
        td_a=mean(all_emotions_mmbrship_dgre(start_p:finish_p,s,h)); % calculated membership degree of emotion label for each person
        td_b=mmbrship_dgre_women(pr,h); % calculated membership degree of prequantifier for each person
        numerator=numerator+ min(td_a,td_b); % calculated numerator in the formula of type-2
        denominator=denominator+td_b; % calculated denominator in the formula of type-2
    end
    td=numerator/denominator;
    
else
    numerator=0;
    denominator=0;
    
    for hh=1:men_number
        td_a=mean(all_emotions_mmbrship_dgre(start_p:finish_p,s,(women_number+hh))); % calculated membership degree of emotion label for each person person
        td_b=mmbrship_dgre_men(pr,hh); % calculated membership degree of prequantifier for each person
        numerator=numerator+ min(td_a,td_b); % calculated numerator in the formula of type-2
        denominator=denominator+td_b; % calculated denominator in the formula of type-2
    end
    td=numerator/denominator;
         
end



% All quantifier functions are defined before and used when they are choosen

if q==1
    [ TD ] = quant_few(td); 
    
elseif q==2
    [ TD ] = quant_most(td);

elseif q==3
    [ TD ] = quant_half(td);
    
elseif q==4
    [ TD ] = quant_at_least_half(td);

else
    [ TD ] = quant_all(td);
end

end