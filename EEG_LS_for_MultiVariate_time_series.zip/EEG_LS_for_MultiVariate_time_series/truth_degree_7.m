function [TD]=truth_degree_7(all_emotions_mmbrship_dgre,seg_number,segment_part1,segment_part2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),  BUT IN THIS DESC. WE ALL USE 'POSITIVE' LABEL. SO FIXED S=3.
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre);
variable=points_size/seg_number; % calculating the segment amount in data (75)

%%% Calculatig the segment_part1's TD
start_p_1=((segment_part1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
finish_p_1=segment_part1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
td1=(sum(sum(all_emotions_mmbrship_dgre(start_p_1:finish_p_1,3,:))))/(variable*people);

%%% Calculatig the segment_part2's TD
start_p_2=((segment_part2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
finish_p_2=segment_part2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
td2=(sum(sum(all_emotions_mmbrship_dgre(start_p_2:finish_p_2,3,:))))/(variable*people);

td=max(0,(td1-td2));

% 'more' quantifier functions are defined before

    [ TD ] = quant_more(td);
end