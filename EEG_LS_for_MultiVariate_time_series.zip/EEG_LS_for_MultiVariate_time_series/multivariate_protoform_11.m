function [MV_P11_audio_sentences,MV_P11_video_sentences,MV_P11_web_sentences]=multivariate_protoform_11(Quantifier,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fa,quant]=size(Quantifier);
[fc,ad_number]=size(Y_ad);
[fd,prequant]=size(Prequantifier);
[fe,gender_number]=size(gender);

MV_P11_audio_sentences=[];
MV_P11_video_sentences=[];
MV_P11_web_sentences=[];

for ad=1:ad_number % looking for ad number
    for q=1:quant  % looking for each used quantifier
        for pr=1:prequant % looking for each used pre-quantifier
            for gend=1:gender_number
                for seg1=1:seg_number % looking for each segment of data
                    for seg2=1:seg_number % looking for each segment of data
                        if seg1~=seg2
                            if ad==1 % for Audio ad
                                [TD]=truth_degree_11(q,pr,gend,seg1,seg2,all_emotions_mmbrship_dgre_audio,mmbrship_dgre_men,mmbrship_dgre_women,seg_number);
                                if TD>=treshold
                                    % Creating summarization and Truth Degree of summary
                                    sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are MORE affected by the ',seg1,'th',' quarter','of the',Y_ad(1,ad),'ad','then the ',seg2,'th',' quarter',num2str(TD)];
                                    MV_P11_audio_sentences=[MV_P11_audio_sentences;sentence];
                                end
                            elseif ad==2 % for Video ad
                                [TD]=truth_degree_11(q,pr,gend,seg1,seg2,all_emotions_mmbrship_dgre_video,mmbrship_dgre_men,mmbrship_dgre_women,seg_number);
                                if TD>=treshold
                                    % Creating summarization and Truth Degree of summary
                                    sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are MORE affected by the ',seg1,'th',' quarter','of the',Y_ad(1,ad),'ad','then the ',seg2,'th',' quarter',num2str(TD)];
                                    MV_P11_video_sentences=[MV_P11_video_sentences;sentence];
                                end
                            else % for Web ad
                                [TD]=truth_degree_11(q,pr,gend,seg1,seg2,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,seg_number);
                                if TD>=treshold
                                    % Creating summarization and Truth Degree of summary
                                    sentence=[Quantifier(1,q),Prequantifier(1,pr),gender(1,gend),' are MORE affected by the ',seg1,'th',' quarter','of the',Y_ad(1,ad),'ad','then the ',seg2,'th',' quarter',num2str(TD)];
                                    MV_P11_web_sentences=[MV_P11_web_sentences;sentence];
                                end    
                            end
                        end
                    end
                end                   
            end
        end
    end
end
end