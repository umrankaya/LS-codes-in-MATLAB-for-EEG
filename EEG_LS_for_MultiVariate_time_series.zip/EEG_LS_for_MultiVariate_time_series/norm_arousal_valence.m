function [arousal_n,valence_n]=norm_arousal_valence(arousal,valence)
% arousal=arousal';
% valence=valence';
[rw,clmn]=size(arousal); % should be [300,17]

arousal_n=[];
valence_n=[];

for j=1:clmn
    for i=1:rw
        arousal_n(i,j)=2*(arousal(i,j)-min(arousal(:,j)))/(max(arousal(:,j))-min(arousal(:,j)))-1;
        valence_n(i,j)=2*(valence(i,j)-min(valence(:,j)))/(max(valence(:,j))-min(valence(:,j)))-1;
    end
end

end