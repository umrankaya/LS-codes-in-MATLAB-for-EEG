clc;
clear all;

%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Getting DATA from source file %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

dataa_audio=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\EEG_LS_for_MultiVariate_time_series\AB_sesli.xlsx"); % loading data
dataa_video=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\EEG_LS_for_MultiVariate_time_series\AB_video.xlsx"); % loading data
dataa_web=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\EEG_LS_for_MultiVariate_time_series\AB_web.xlsx"); % loading data

dataa_men=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\EEG_LS_for_MultiVariate_time_series\ages_men.xlsx"); % loading data
dataa_women=readtable("D:\Users\umran.kaya\Desktop\EEG_Data\Matlab\EEG_LS_for_MultiVariate_time_series\ages_women.xlsx"); % loading data

     %&& Filling missing values (using moving average method with length 5) and converting from table to array (matrix) &&%
EEG_audio=fill_missing_data(dataa_audio,5);
EEG_video=fill_missing_data(dataa_video,5);
EEG_web=fill_missing_data(dataa_web,5);

     %&& Calculating Arousal and Valence values and Resulting with converting them with normalization method &&%
                                        %%% for AUDIO EEG DATA %%%%
[arousal_audio,valence_audio]=arousal_valence_calc(EEG_audio); % a function that calculating the arousal and valence values
[arousal_audio_n,valence_audio_n]=norm_arousal_valence(arousal_audio,valence_audio); % a function that normalize the Arousal and Valence between [-1,1] interval
                                        %%% for VIDEO EEG DATA %%%%
[arousal_video,valence_video]=arousal_valence_calc(EEG_video); % a function that calculating the arousal and valence values
[arousal_video_n,valence_video_n]=norm_arousal_valence(arousal_video,valence_video); % a function that normalize the Arousal and Valence between [-1,1] interval
                                         %%% for WEB EEG DATA %%%%
[arousal_web,valence_web]=arousal_valence_calc(EEG_web); % a function that calculating the arousal and valence values
[arousal_web_n,valence_web_n]=norm_arousal_valence(arousal_web,valence_web); % a function that normalize the Arousal and Valence between [-1,1] interval

          %&& Calculating AW Index and Resulting with converting them with normalization method &&%
 %%% for AUDIO EEG DATA %%%%
 [AW_audio]=AW_calc(EEG_audio);
 [AW_audio_n]=norm_AW(AW_audio);
 %%% for VIDEO EEG DATA %%%%
 [AW_video]=AW_calc(EEG_video);
 [AW_video_n]=norm_AW(AW_video);
 %%% for WEB EEG DATA %%%%
 [AW_web]=AW_calc(EEG_web);
 [AW_web_n]=norm_AW(AW_web);

 %& Until this point, we got the data and make the preprocess (filling missing data,calc arousal/valence, AW,)
 %& Now, we will create the fuzzy sets. Before creating the protoforms, we should create the labels fuzzy sets to get membership degrees while
 %calculating the truth values.
 
 %%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Creating FUZZY SETS for ALL LABELS %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                                          
%& We have 2 type fuzzy sets. First one is about 3 type emotions (all emotion, basic emotions and AW index). 
%& Second type fuzzy sets is about Quantifiers. These quantifiers are {few, half, at_least_half, most, all}.
%& And more there is a label used for comparing is "more". 

                     %&---------------- EMOTIONS FUZZY SETS---------------- %&
%& 1) ALL EMOTIONS LABELS:

labels_all_emotion={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'}; % labels used in emotion detection. This data used in label_fuzzy_set

% These "all_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*16*17. 
% It means that for all 17 people, 300 time points' value is converted to 16 emotions' membership degree.

[all_emotions_mmbrship_dgre_audio]=mem_degree_for_all_emotion(arousal_audio_n,valence_audio_n,labels_all_emotion);
[all_emotions_mmbrship_dgre_video]=mem_degree_for_all_emotion(arousal_video_n,valence_video_n,labels_all_emotion);
[all_emotions_mmbrship_dgre_web]=mem_degree_for_all_emotion(arousal_web_n,valence_web_n,labels_all_emotion);


%& 2) BASIC EMOTIONS LABELS:

labels_basic_emotion={'thrilling','hard-pressed','pessimist','mitigated'}; % labels used in emotion detection. This data used in basic_labels_fuzzy_set

% These "basic_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*4*17. 
% It means that for all 17 people, 300 time points' value is converted to 4 emotions' membership degree.

[basic_emotions_mmbrship_dgre_audio]=mem_degree_for_basic_emotion(arousal_audio_n,valence_audio_n,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_video]=mem_degree_for_basic_emotion(arousal_video_n,valence_video_n,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_web]=mem_degree_for_basic_emotion(arousal_web_n,valence_web_n,labels_basic_emotion);

%& 3) AW INDEX LABELS:

labels_AW_emotion={'negative','neutral','positive'}; % labels used in emotion detection. This data used in AW_labels_fuzzy_set

% These "AW_index_mmbrship_dgre_audio/video/web" matrix size is 300*3*17. 
% It means that for all 17 people, 300 time points' value is converted to 3 emotions' membership degree.

[AW_index_mmbrship_dgre_audio]=mem_degree_for_AW_index(AW_audio_n,labels_AW_emotion);
[AW_index_mmbrship_dgre_video]=mem_degree_for_AW_index(AW_video_n,labels_AW_emotion);
[AW_index_mmbrship_dgre_web]=mem_degree_for_AW_index(AW_web_n,labels_AW_emotion);

%& 4) AGE LABELS:
gender={'women','men'};
Prequantifier={'young','adult','old'};

% Totaly, there are 17 volunteer. 5 of these are women and 12 of these are men.
% We create 3 labeled fuzzy sets {'young','adult','old'} for each gender.

[mmbrship_dgre_men]=fuzzy_c_means(dataa_men,3);
[mmbrship_dgre_women]=fuzzy_c_means(dataa_women,3);


%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------%%% LINGUISTIC SUMMARIES %%%%-----------------------------------%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

Y_ad={'audio','video','web'};
Quantifier={'few','most','half','at least half','all'};
Y_segment={'first','second','third','fourth'};

treshold=input('Please, write the TRESHOLD:  '); % indicates the minimum truth degree to be referenced
seg_number=input('Please, write the SEGMENTATION NUMBER:  ');  % shows how many segments it will examine the ad.
% treshold=0.5; % indicates the minimum truth degree to be referenced
% seg_number=4;  % shows how many segments it will examine the ad.

% There are 2 type descriptions. First type is general descriptions has 4 protoforms. 
% Second type of description is comparing ads, ads' parts and emotions. 

%*******-----------------------A)GENERAL DESCRIPTIONS-----------------------*******%

%  1) 1. protoform for each 3 advertising type.
%------"Q time of Y ad, people are S.[TD]"--------%
% 1.1) Sentences created by all_emotions
[MV_P1_audio_all_emotion,MV_P1_video_all_emotion,MV_P1_web_all_emotion]=multivariate_protoform_1(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold);
%------"Q time of Y ad, people are S.[TD]"--------%
% 1.2) Sentences created by basic_emotions
[MV_P1_audio_basic_emotion,MV_P1_video_basic_emotion,MV_P1_web_basic_emotion]=multivariate_protoform_1(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,Y_ad,treshold);


%  2) 2. protoform for each 3 advertising type
%------"Q time of the Y_seg quarter of Y ad, people are S.[TD]"-----%
% 2.1) Sentences created by all_emotions
[MV_P2_audio_sentences,MV_P2_video_sentences,MV_P2_web_sentences]=multivariate_protoform_2(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold,seg_number);
%------"Q time of the Y_seg quarter of Y ad, people are S.[TD]"-----%
% 2.2) Sentences created by basic_emotions
[MV_P2_audio_basic_emotion,MV_P2_video_basic_emotion,MV_P2_web_basic_emotion]=multivariate_protoform_2(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,Y_ad,treshold,seg_number);


%  3) 3. protoform for each 3 advertising type
%------"Q time of Y ad, people have S tends for ad.[TD]"--------%
[MV_P3_audio_sentences,MV_P3_video_sentences,MV_P3_web_sentences]=multivariate_protoform_3(Quantifier,labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold);

%  4) 4. protoform for each 3 advertising type
%------"Q time of the Y_seg quarter of Y ad, people have S tends for ad.[TD]"-------%
[MV_P4_audio_AW_index,MV_P4_video_AW_index,MV_P4_web_AW_index]=multivariate_protoform_4(Quantifier,labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number);

%  5) 5. protoform for each 3 advertising type.
%------"Q (Wg(Sg)) Y_1 are S in Y_2 ad.[TD]"--------%
% 5.1) Sentences created by all_emotions
[MV_P5_audio_all_emotion,MV_P5_video_all_emotion,MV_P5_web_all_emotion]=multivariate_protoform_5(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold);
% 5.2) Sentences created by basic_emotions
[MV_P5_audio_basic_emotion,MV_P5_video_basic_emotion,MV_P5_web_basic_emotion]=multivariate_protoform_5(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold);
% 5.3) Sentences created by AW_index
[MV_P5_audio_AW_index,MV_P5_video_AW_index,MV_P5_web_AW_index]=multivariate_protoform_5(Quantifier,labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold);


%  6) 6. protoform for each 3 advertising type.
%------"Q (Wg(Sg)) Y_1 are S in the Y_3 quarter of the Y_2 ad.[TD]"--------%
% 6.1) Sentences created by all_emotions
[MV_P6_audio_all_emotion,MV_P6_video_all_emotion,MV_P6_web_all_emotion]=multivariate_protoform_6(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number);
% 6.2) Sentences created by basic_emotions
[MV_P6_audio_basic_emotion,MV_P6_video_basic_emotion,MV_P6_web_basic_emotion]=multivariate_protoform_6(Quantifier,labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number);
% 6.3) Sentences created by AW_index
[MV_P6_audio_AW_index,MV_P6_video_AW_index,MV_P6_web_AW_index]=multivariate_protoform_6(Quantifier,labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number);

%*******-----------------------B)COMPARATIVE DESCRIPTIONS-----------------------*******%

%  7) 7. protoform for each 3 advertising type.
%--" The Y1 quarter of the Y ad has a more impact than the Y2 quarter.[TD]"--------%
[MV_P7_audio_Comparative,MV_P7_video_Comparative,MV_P7_web_Comparative]=multivariate_protoform_7(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number);

%  8) 8. protoform for each 3 advertising type. 
%--" In general, Y_1 ad has a more impact than Y_2 ad. [TD]"--------%
[MV_P8_Comparing_Ads]=multivariate_protoform_8(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold);

%  9) 9. protoform for each 3 advertising type. 
%--" The S tends is observed Q1 of the time in the Y_1 quarter of the AD_1, Q2 of the time in the Y_2 quarter of the AD_2. [TD]"--------%
[MV_P9_Comparing_Ads_quarters]=multivariate_protoform_9(Quantifier,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number);

%  10) 10. protoform for each 3 advertising type. 
%--" The S tends is observed Q1 of the time in the Y_1 quarter of the AD_1, Q2 of the time in the Y_2 quarter of the AD_2. [TD]"--------%
[MV_P10_comparing_mostly_all_emotion]=multivariate_protoform_10(labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold);
[MV_P10_comparing_mostly_basic_emotion]=multivariate_protoform_10(labels_basic_emotion,basic_emotions_mmbrship_dgre_audio,basic_emotions_mmbrship_dgre_video,basic_emotions_mmbrship_dgre_web,Y_ad,treshold);
[MV_P10_comparing_mostly_AW_index]=multivariate_protoform_10(labels_AW_emotion,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold);

%  11) 11. protoform for each 3 advertising type. 
%--" Q (Wg(Sg)) Y_1 are more affected by the Y_3 quarter of the Y_2 ad then the Y_3' quarter. [TD]"--------%
[MV_P11_audio_AW_index,MV_P11_video_AW_index,MV_P11_web_AW_index]=multivariate_protoform_11(Quantifier,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold,seg_number);

%  12) 12. protoform for each 3 advertising type. 
%--" In general, Y_2 ad affected positively Y_1 more than Y_2' ad. [TD]"--------%
[MV_P12_Comparing_Ads]=multivariate_protoform_12(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,gender,treshold);

%  13) 13. protoform for each 3 advertising type. 
%--" (Wg(Sg)) Y_1 are more affected by Y_2 ad more than the (Wg(Sg))' Y_1. [TD]"--------%
[MV_P13_audio_sentences,MV_P13_video_sentences,MV_P13_web_sentences]=multivariate_protoform_13(all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,Prequantifier,gender,treshold);

%  14) 14. protoform for each 3 advertising type. 
%--" Y_1 are more affected positively by Y_2 ad than the Y_1'. [TD]"--------%
[MV_P14_Comparing_Ads]=multivariate_protoform_14(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,Y_ad,gender,treshold);

