function [TD]=truth_degree_10(s1,s2,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,ad1,ad2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 's' represents the used Summerizer (emotion label).
% 'all_emotions_mmbrship_dgre_audio' represents calculated membership degree matrix,
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre_audio);


%%% Calculatig the Ad1's TD
if ad1==1
    td1=(sum(sum(all_emotions_mmbrship_dgre_audio(:,s1,:))))/(points_size*people); 
elseif ad1==2
    td1=(sum(sum(all_emotions_mmbrship_dgre_video(:,s1,:))))/(points_size*people);  
else
    td1=(sum(sum(all_emotions_mmbrship_dgre_web(:,s1,:))))/(points_size*people);      
end


%%% Calculatig the Ad2's TD
if ad2==1
    td2=(sum(sum(all_emotions_mmbrship_dgre_audio(:,s2,:))))/(points_size*people); 
elseif ad2==2
    td2=(sum(sum(all_emotions_mmbrship_dgre_video(:,s2,:))))/(points_size*people);  
else
    td2=(sum(sum(all_emotions_mmbrship_dgre_web(:,s2,:))))/(points_size*people);      
end

td=max(td1,td2);

% 'most' quantifier functions are defined before.

    [ TD ] = quant_most(td);
end