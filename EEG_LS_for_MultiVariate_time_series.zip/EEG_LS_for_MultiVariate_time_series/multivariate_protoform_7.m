function [MV_P7_audio_Comparative,MV_P7_video_Comparative,MV_P7_web_Comparative]=multivariate_protoform_7(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fy,ad_number]=size(Y_ad);
MV_P7_audio_Comparative=[];
MV_P7_video_Comparative=[];
MV_P7_web_Comparative=[];

for ad=1:ad_number % looking for ad number
    for seg1=1:seg_number % looking for each segment of data
        for seg2=1:seg_number % looking for each segment of data
            if seg1~=seg2
                if ad==1 % for Audio ad
                    [TD]=truth_degree_7(AW_index_mmbrship_dgre_audio,seg_number,seg1,seg2);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter',num2str(TD)];
                        MV_P7_audio_Comparative=[MV_P7_audio_Comparative;sentence];
                    end
                elseif ad==2 % for Video ad
                    [TD]=truth_degree_7(AW_index_mmbrship_dgre_video,seg_number,seg1,seg2);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter',num2str(TD)];
                        MV_P7_video_Comparative=[MV_P7_video_Comparative;sentence];
                    end
                else % for Web ad
                    [TD]=truth_degree_7(AW_index_mmbrship_dgre_web,seg_number,seg1,seg2);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=['The',seg1,'quarter of the',Y_ad(1,ad),'ad','has a MORE POSITIVE impact then the ',seg2,'quarter',num2str(TD)];
                        MV_P7_web_Comparative=[MV_P7_web_Comparative;sentence];
                    end
                end
            end
        end
    end
end
end