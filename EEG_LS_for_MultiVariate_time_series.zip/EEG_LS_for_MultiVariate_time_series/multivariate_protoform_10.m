function [MV_P10_comparing_mostly]=multivariate_protoform_10(labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fl,summarizer]=size(labels_all_emotion);
[fy,ad_number]=size(Y_ad);
MV_P10_comparing_mostly=[];


for ad1=1:(ad_number-1)   % looking for ad1 number 
    for ad2=2:ad_number    % looking for ad2 number
        if ad1~=ad2       % looking for not to be the same ad.
            for s1=1:summarizer % looking for each used emotion1
                for s2=1:summarizer % looking for each used emotion2
                    [TD]=truth_degree_10(s1,s2,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,ad1,ad2);
                    if TD>=treshold
                        if s1 ~= s2
                            % This part creates sentences, If the emotion is DIFFERENT.
                            sentence=['While the',labels_all_emotion(1,s1), 'emotion is observed MOST of the time in the',Y_ad(1,ad1),'ad, ','as opposed to this, ',labels_all_emotion(1,s2), 'emotion is observed MOST of the time in the',Y_ad(1,ad2),'ad, ',num2str(TD)];
                            MV_P10_comparing_mostly=[MV_P10_comparing_mostly;sentence];
                        else
                            % This part creates sentences, If the emotion is SAME.
                            sentence=[labels_all_emotion(1,s1), 'emotion',' is observed',' MOST time of',' BOTH in the',Y_ad(1,ad1),'ad, ','and',Y_ad(1,ad2),'ad, ',num2str(TD)];
                            MV_P10_comparing_mostly=[MV_P10_comparing_mostly;sentence];
                        end
                    end
                end
            end
        end
    end
end

end