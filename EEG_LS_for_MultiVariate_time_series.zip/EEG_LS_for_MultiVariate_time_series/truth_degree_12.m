function [TD]=truth_degree_12(gend,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,mmbrship_dgre_men,mmbrship_dgre_women,ad1,ad2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 's' represents the used Summerizer (emotion label),  BUT IN THIS DESC. WE ALL USE 'POSITIVE' LABEL. SO FIXED S=3.
% 'AW_index_mmbrship_dgre_audio' represents calculated membership degree matrix,
% 'segment_part' represents which segment of data has been used.

[points_size,emotion_size,people]=size(AW_index_mmbrship_dgre_audio);

[group1,women_number]=size(mmbrship_dgre_women); % there are 5 women 
[group2,men_number]=size(mmbrship_dgre_men); % there are 12 men 

if gend==1 % if gender is women
       
        %%% Calculatig the Ad1's TD
        if ad1==1
            td1=(sum(sum(AW_index_mmbrship_dgre_audio(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label
        elseif ad1==2
            td1=(sum(sum(AW_index_mmbrship_dgre_video(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label   
        else
            td1=(sum(sum(AW_index_mmbrship_dgre_web(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label       
        end


        %%% Calculatig the Ad2's TD
        if ad2==1
            td2=(sum(sum(AW_index_mmbrship_dgre_audio(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label
        elseif ad2==2
            td2=(sum(sum(AW_index_mmbrship_dgre_video(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label   
        else
            td2=(sum(sum(AW_index_mmbrship_dgre_web(:,3,1:women_number))))/(points_size*women_number); % 3 is used to calculate 'positive' label       
        end
        
else 
        %%% Calculatig the Ad1's TD
        if ad1==1
            td1=(sum(sum(AW_index_mmbrship_dgre_audio(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label
        elseif ad1==2
            td1=(sum(sum(AW_index_mmbrship_dgre_video(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label   
        else
            td1=(sum(sum(AW_index_mmbrship_dgre_web(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label       
        end


        %%% Calculatig the Ad2's TD
        if ad2==1
            td2=(sum(sum(AW_index_mmbrship_dgre_audio(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label
        elseif ad2==2
            td2=(sum(sum(AW_index_mmbrship_dgre_video(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label   
        else
            td2=(sum(sum(AW_index_mmbrship_dgre_web(:,3,(women_number+1):people))))/(points_size*men_number); % 3 is used to calculate 'positive' label       
        end  
    
end
td=max(0,(td1-td2));

% 'more' quantifier functions are defined before and used.

    [ TD ] = quant_more(td);
end