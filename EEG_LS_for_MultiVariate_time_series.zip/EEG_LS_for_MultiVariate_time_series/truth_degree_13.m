function [TDD]=truth_degree_13(gend,pr1,pr2,all_emotions_mmbrship_dgre,mmbrship_dgre_men,mmbrship_dgre_women)


%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'gend' represents the used Gender,
% 'pr1' represents the used prequantifier1,
% 'pr2' represents the used prequantifier2,
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,

[group1,women_number]=size(mmbrship_dgre_women); % there are 5 women 
[group2,men_number]=size(mmbrship_dgre_men); % there are 12 men 

if gend==1 % if gender is women
    numerator1=0;
    denominator1=0;
    numerator2=0;
    denominator2=0;
    
    for h=1:women_number
        
        %%% Calculatig the pr1's TD

        td_a_1=mean(all_emotions_mmbrship_dgre(:,3,h)); % calculated membership degree of emotion label for each person
        td_b_1=mmbrship_dgre_women(pr1,h); % calculated membership degree of prequantifier for each person
        numerator1=numerator1+ min(td_a_1,td_b_1); % calculated numerator in the formula of type-2
        denominator1=denominator1+td_b_1; % calculated denominator in the formula of type-2
        
        %%% Calculatig the pr2's TD

        td_a_2=mean(all_emotions_mmbrship_dgre(:,3,h)); % calculated membership degree of emotion label for each person
        td_b_2=mmbrship_dgre_women(pr2,h); % calculated membership degree of prequantifier for each person
        numerator2=numerator2+ min(td_a_2,td_b_2); % calculated numerator in the formula of type-2
        denominator2=denominator2+td_b_2; % calculated denominator in the formula of type-2
    end
    TD1=numerator1/denominator1;
    TD2=numerator2/denominator2;
    
    td=max(0,(TD1-TD2));
    
else
    numerator1=0;
    denominator1=0;
    numerator2=0;
    denominator2=0;
    
    for hh=1:men_number
        
        %%% Calculatig the pr1's TD
        
        td_a_1=mean(all_emotions_mmbrship_dgre(:,3,(women_number+hh))); % calculated membership degree of emotion label for each person person
        td_b_1=mmbrship_dgre_men(pr1,hh); % calculated membership degree of prequantifier for each person
        numerator1=numerator1+ min(td_a_1,td_b_1); % calculated numerator in the formula of type-2
        denominator1=denominator1+td_b_1; % calculated denominator in the formula of type-2
        
        %%% Calculatig the pr2's TD

        td_a_2=mean(all_emotions_mmbrship_dgre(:,3,(women_number+hh))); % calculated membership degree of emotion label for each person person
        td_b_2=mmbrship_dgre_men(pr2,hh); % calculated membership degree of prequantifier for each person
        numerator2=numerator2+ min(td_a_2,td_b_2); % calculated numerator in the formula of type-2
        denominator2=denominator2+td_b_2; % calculated denominator in the formula of type-2
    end
    TD1=numerator1/denominator1;
    TD2=numerator2/denominator2;
       
    td=max(0,(TD1-TD2));
    
end

% 'more' quantifier functions are defined before

    [ TDD ] = quant_more(td);

end