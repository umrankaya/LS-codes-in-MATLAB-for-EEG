function [TDD]=truth_degree_11(q,pr,gend,seg1,seg2,all_emotions_mmbrship_dgre,mmbrship_dgre_men,mmbrship_dgre_women,seg_number)


%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 'q' represents the used Quantifier,
% 's' represents the used Summerizer (emotion label),
% 'all_emotions_mmbrship_dgre' represents calculated membership degree matrix,

[points_size,emotion_size,people]=size(all_emotions_mmbrship_dgre);
variable=points_size/seg_number; % calculating the segment amount in data (75)


[group1,women_number]=size(mmbrship_dgre_women); % there are 5 women 
[group2,men_number]=size(mmbrship_dgre_men); % there are 12 men 

if gend==1 % if gender is women
    numerator1=0;
    denominator1=0;
    numerator2=0;
    denominator2=0;
    
    for h=1:women_number
        
        %%% Calculatig the segment_part1's TD
        start_p_1=((seg1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
        finish_p_1=seg1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)

        td_a_1=mean(all_emotions_mmbrship_dgre(start_p_1:finish_p_1,3,h)); % calculated membership degree of emotion label for each person
        td_b_1=mmbrship_dgre_women(pr,h); % calculated membership degree of prequantifier for each person
        numerator1=numerator1+ min(td_a_1,td_b_1); % calculated numerator in the formula of type-2
        denominator1=denominator1+td_b_1; % calculated denominator in the formula of type-2
        
        %%% Calculatig the segment_part2's TD
        start_p_2=((seg2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
        finish_p_2=seg2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)

        td_a_2=mean(all_emotions_mmbrship_dgre(start_p_2:finish_p_2,3,h)); % calculated membership degree of emotion label for each person
        td_b_2=mmbrship_dgre_women(pr,h); % calculated membership degree of prequantifier for each person
        numerator2=numerator2+ min(td_a_2,td_b_2); % calculated numerator in the formula of type-2
        denominator2=denominator2+td_b_2; % calculated denominator in the formula of type-2
    end
    td_1=numerator1/denominator1;
    td_2=numerator2/denominator2;
    
    if q==1
        [ TD1 ] = quant_few(td_1); 
        [ TD2 ] = quant_few(td_2);
    elseif q==2
        [ TD1 ] = quant_most(td_1);
        [ TD2 ] = quant_most(td_2);
    elseif q==3
        [ TD1 ] = quant_half(td_1);
        [ TD2 ] = quant_half(td_2);
    elseif q==4
        [ TD1 ] = quant_at_least_half(td_1);
        [ TD2 ] = quant_at_least_half(td_2);
    else
        [ TD1 ] = quant_all(td_1);
        [ TD2 ] = quant_all(td_2);
    end
   
    td=max(0,(TD1-TD2));
    
else
    numerator1=0;
    denominator1=0;
    numerator2=0;
    denominator2=0;
    
    for hh=1:men_number
        
        %%% Calculatig the segment_part2's TD
        start_p_1=((seg1-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
        finish_p_1=seg1*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)
        
        td_a_1=mean(all_emotions_mmbrship_dgre(start_p_1:finish_p_1,3,(women_number+hh))); % calculated membership degree of emotion label for each person person
        td_b_1=mmbrship_dgre_men(pr,hh); % calculated membership degree of prequantifier for each person
        numerator1=numerator1+ min(td_a_1,td_b_1); % calculated numerator in the formula of type-2
        denominator1=denominator1+td_b_1; % calculated denominator in the formula of type-2
        
        %%% Calculatig the segment_part2's TD
        start_p_2=((seg2-1)*variable)+1; % calculating the start point of segment (for example: 3. segment start point is 151)
        finish_p_2=seg2*variable; % calculating finish point of segment (for example: 3. segment finish point is 225)

        td_a_2=mean(all_emotions_mmbrship_dgre(start_p_2:finish_p_2,3,(women_number+hh))); % calculated membership degree of emotion label for each person person
        td_b_2=mmbrship_dgre_men(pr,hh); % calculated membership degree of prequantifier for each person
        numerator2=numerator2+ min(td_a_2,td_b_2); % calculated numerator in the formula of type-2
        denominator2=denominator2+td_b_2; % calculated denominator in the formula of type-2
    end
    td_1=numerator1/denominator1;
    td_2=numerator2/denominator2;
    
    if q==1
        [ TD1 ] = quant_few(td_1); 
        [ TD2 ] = quant_few(td_2);
    elseif q==2
        [ TD1 ] = quant_most(td_1);
        [ TD2 ] = quant_most(td_2);
    elseif q==3
        [ TD1 ] = quant_half(td_1);
        [ TD2 ] = quant_half(td_2);
    elseif q==4
        [ TD1 ] = quant_at_least_half(td_1);
        [ TD2 ] = quant_at_least_half(td_2);
    else
        [ TD1 ] = quant_all(td_1);
        [ TD2 ] = quant_all(td_2);
    end
   
    td=max(0,(TD1-TD2));
    
end



% 'more' quantifier functions are defined before

    [ TDD ] = quant_more(td);

end