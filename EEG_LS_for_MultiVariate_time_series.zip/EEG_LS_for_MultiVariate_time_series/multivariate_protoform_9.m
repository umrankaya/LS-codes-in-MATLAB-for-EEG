function [MV_P9_Comparing_Ads_quarters]=multivariate_protoform_9(Quantifier,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,Y_ad,treshold,seg_number)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fq,quant]=size(Quantifier);

[fy,ad_number]=size(Y_ad);
MV_P9_Comparing_Ads_quarters=[];


for ad1=1:(ad_number-1)   % looking for number of ad1
    for ad2=2:ad_number % looking for number of ad2
        if ad1~=ad2       % looking for not to be the same ad.
            for q1=1:quant  % looking for each used quantifier1
                for q2=1:quant % looking for each used quantifier2
                    for seg1=1:seg_number % looking for each segment of ad1 data
                        for seg2=1:seg_number % looking for each segment of ad2 data
                            [TD]=truth_degree_9(q1,q2,AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,ad1,ad2,seg_number,seg1,seg2);
                            if TD>=treshold
                                % Creating summarization and Truth Degree of summary
                                sentence=['POSITIVE tends is observed ',Quantifier(1,q1),'time ','in the quarter_',seg1,'of the ',Y_ad(1,ad1),'ad,', Quantifier(1,q2),'time ','in the quarter_',seg2,'of the ',Y_ad(1,ad2),'ad,',num2str(TD)];
                                MV_P9_Comparing_Ads_quarters=[MV_P9_Comparing_Ads_quarters;sentence];
                            end
                        end
                    end
                end
            end
        end
    end
end

end